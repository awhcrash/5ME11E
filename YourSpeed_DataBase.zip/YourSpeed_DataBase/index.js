// index.js

const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const cors = require('cors');

// Enable CORS for all requests
app.use(cors());
//Enable CORS for requests from specific origin
app.use(cors({
  origin: 'http://your-unity-domain.com'
}));





// MongoDB connection
mongoose.connect('mongodb+srv://awhcrash:awhy@cluster0.wnah5ct.mongodb.net/speedo', {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => {
  console.log("Connected to MongoDB");
}).catch((err) => {
  console.error("Error connecting to MongoDB:", err);
});


// Add this middleware to your Node.js application to enable CORS
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*'); // Allow requests from any origin
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
  next();
});



// Define a schema for your data
const dataSchema = new mongoose.Schema({
  yourTime: String,
  yourSpeed: Number,
  date: String
});

// Create a model based on the schema
const Data = mongoose.model('Data', dataSchema);

// Middleware to parse JSON bodies
app.use(bodyParser.json());

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

// Route to handle POST requests
app.post('/data', async (req, res) => {
  try {
    // Create a new data instance
    const newData = new Data({
      yourTime: req.body.yourTime,
      yourSpeed: req.body.yourSpeed,
      date: req.body.date
    });
    
    // Save the data to MongoDB
    await newData.save();
    
    res.status(201).send("Data saved successfully");
  } catch (err) {
    console.error("Error saving data:", err);
    res.status(500).send("Internal Server Error");
  }
});

// Route to fetch data from MongoDB
app.get('/data', async (req, res) => {
  try {
    const data = await Data.find();
    res.json(data);
  } catch (err) {
    console.error("Error fetching data:", err);
    res.status(500).send("Internal Server Error");
  }
});

// Route to fetch just "yourSpeed" data from MongoDB
app.get('/data', async (req, res) => {
  try {
    const data = await Data.find();
    const yourSpeedArray = data.map(item => item.yourSpeed); // Extract yourSpeed values into an array

    // Construct an object with the yourSpeed array
    const responseData = {
      yourSpeed: yourSpeedArray
    };

    res.json(responseData); // Send the response in JSON format
  } catch (err) {
    console.error("Error fetching data:", err);
    res.status(500).send("Internal Server Error");
  }
});


// Route to serve the home page
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'home.html'));
});


// Route to serve the submit page
app.get('/submit', (req, res) => {
  res.sendFile(path.join(__dirname, 'submit.html'));
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});