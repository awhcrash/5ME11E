using UnityEngine;
using System;
using System.Collections;
using UnityEngine.Networking;
using UnityEngine.EventSystems;

public class DataSender : MonoBehaviour, IPointerDownHandler, IPointerUpHandler
{
    private const string url = "http://localhost:3000/data";

    private bool isLongPressing = false;
    private Coroutine longPressCoroutine;
    private float longPressDuration = 1.0f;

    public StopwatchController stopwatchController;

    public void OnPointerDown(PointerEventData eventData)
    {
        isLongPressing = true;
        longPressCoroutine = StartCoroutine(LongPressCoroutine());
    }

    public void OnPointerUp(PointerEventData eventData)
    {
        isLongPressing = false;
        if (longPressCoroutine != null)
        {
            StopCoroutine(longPressCoroutine);
        }
    }

    private IEnumerator LongPressCoroutine()
    {
        yield return new WaitForSeconds(longPressDuration);

        string yourTime = stopwatchController.GetElapsedTime();
        float yourSpeed = stopwatchController.GetSpeed();
        string date = DateTime.Now.ToString("yyyy-MM-dd");

        // Create JSON data
        string jsonData = "{\"yourTime\":\"" + yourTime + "\",\"yourSpeed\":\"" + yourSpeed + "\",\"date\":\"" + date + "\"}";

        // Create request
        UnityWebRequest request = new UnityWebRequest(url, "POST");
        byte[] bodyRaw = System.Text.Encoding.UTF8.GetBytes(jsonData);
        request.uploadHandler = (UploadHandler)new UploadHandlerRaw(bodyRaw);
        request.downloadHandler = (DownloadHandler)new DownloadHandlerBuffer();
        request.SetRequestHeader("Content-Type", "application/json");

        // Send request
        yield return request.SendWebRequest();

        // Check for errors
        if (request.result != UnityWebRequest.Result.Success)
        {
            Debug.LogError("Failed to send data: " + request.error);
        }
        else
        {
            Debug.Log("Data sent successfully");
        }
    }
}
