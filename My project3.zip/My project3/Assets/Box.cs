using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Box : MonoBehaviour
{
    public float speed = 2f; // Speed of movement in meters per second

    private bool isMoving = false;

    void Update()
    {
        if (isMoving)
        {
            // Move the box along the Z-axis
            transform.Translate(Vector3.forward * speed * Time.deltaTime);
        }
    }

    public void StartMovement()
    {
        isMoving = true;
    }
}
