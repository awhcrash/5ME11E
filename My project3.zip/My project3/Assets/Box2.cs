using UnityEngine;
using System.Collections;
using UnityEngine.Networking;
using SimpleJSON;

public class Box2Mover : MonoBehaviour
{
    private ArrayList speeds = new ArrayList(); // ArrayList to store yourSpeed values
    private float chosenSpeed = 1.75f; // Default speed
    private bool isMoving = false;
    private bool speedsFetched = false; // Flag to track whether speeds have been fetched

    void Start()
    {
        StartCoroutine(FetchSpeeds()); // Start coroutine to fetch speeds from Node.js app
    }

    void Update()
    {
        if (speedsFetched && !isMoving)
        {
            ChooseRandomSpeed(); // Choose a random speed when speeds are fetched and the game starts
            //isMoving = true;
        }

        if (isMoving)
        {
            // Move Box2 along the Z-axis with the chosen random speed
            transform.Translate(Vector3.forward * chosenSpeed * Time.deltaTime);
        }
    }

    IEnumerator FetchSpeeds()
    {
        string url = "http://localhost:3000/data"; // URL of your Node.js application

        // Create UnityWebRequest
        using (UnityWebRequest www = UnityWebRequest.Get(url))
        {
            yield return www.SendWebRequest();

            if (www.result != UnityWebRequest.Result.Success)
            {
                Debug.LogError("Error fetching speeds: " + www.error);
            }
            else
            {
                // Parse JSON response
                string jsonString = www.downloadHandler.text;
                speeds.Clear(); // Clear existing speeds
                JSONArray data = JSON.Parse(jsonString).AsArray;

                // Iterate over JSON array and add yourSpeed values to the speeds list
                foreach (JSONNode item in data)
                {
                    speeds.Add(item["yourSpeed"].AsFloat);
                }

                // Debug.Log speeds
                Debug.Log("Speeds: " + string.Join(", ", speeds.ToArray()));
                speedsFetched = true; // Set speedsFetched to true once speeds are fetched
            }
        }
    }

    void ChooseRandomSpeed()
    {
        if (speeds.Count > 0)
        {
            // Choose a random index from the speeds array
            int randomIndex = Random.Range(0, speeds.Count);
            chosenSpeed = (float)speeds[randomIndex];
            Debug.Log("chosenSpeed: " + chosenSpeed);
        }
        else
        {
            Debug.LogWarning("No speeds fetched yet. . Using default speed.");
        }


    }

    public void StartMovement()
    {
        isMoving = true;
    }

}
