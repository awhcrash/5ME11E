using UnityEngine;
using UnityEngine.UI;

public class StopwatchController : MonoBehaviour
{
    public Text timerText; // Reference to the UI Text element for displaying time

    public float elapsedTime = 0f;
    private bool isRunning = false;

    // Update elapsedTime and update the timer text if the stopwatch is running
    void Update()
    {
        if (isRunning)
        {
            elapsedTime += Time.deltaTime; // Update elapsedTime
            Debug.Log("Updated elapsedTime: " + elapsedTime); // Add debug log
            UpdateTimerText(); // Update the timer text

        }
    }

    // Toggle the stopwatch state (start/stop)
    public void ToggleStopwatch()
    {
        isRunning = !isRunning; // Toggle isRunning
    }

    // Get the formatted elapsed time as a string
    public string GetElapsedTime()
    {
        // Format the elapsed time into minutes, seconds, and milliseconds
        int minutes = Mathf.FloorToInt(elapsedTime / 60f);
        int seconds = Mathf.FloorToInt(elapsedTime % 60f);
        int milliseconds = Mathf.FloorToInt((elapsedTime * 1000f) % 1000f);

        // Add debug log to track elapsedTime
        Debug.Log("Current elapsedTime: " + elapsedTime);

        // Return the formatted elapsed time as a string
        return string.Format("{0:00}:{1:00}:{2:000}", minutes, seconds, milliseconds);
    }

    // Get the current speed based on elapsed time
    public float GetSpeed()
    {
        // Calculate speed (distance / time)
        float speed = elapsedTime > 0f ? 25f / elapsedTime : 0f; // Avoid dividing by zero

        // Return the calculated speed
        return speed;
    }

    // Update the timer text to display the current stopwatch time and speed
    private void UpdateTimerText()
    {
        // Get the formatted elapsed time and speed
        string elapsedTimeText = GetElapsedTime();
        float speed = GetSpeed();

        // Update the Text element to display the current stopwatch time and speed
        timerText.text = "Time: " + elapsedTimeText + "\nYour Speed: " + speed.ToString("0.00") + " m/s \nRedUser Speed: 2 m/s \nHamilton Speed: 1.75 m/s (Random)";
    }

}

